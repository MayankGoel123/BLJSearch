package com.blj.search;

import android.app.ActionBar;
import android.app.Fragment;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import com.blj.search.FreeImagesActivity;
import com.blj.search.UnsplashActivity;
import com.blj.search.StockSnapActivity;
import com.blj.search.PixabayActivity;
import com.blj.search.PexelsActivity;

public class MyWebViewFragment extends Fragment {

    private WebView mWebView;
    private ProgressBar mProgressbar;

    ImageButton imageButton1, imageButton2, imageButton3, imageButton4, imageButton5;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_webview, container, false);

        mWebView = (WebView) view.findViewById(R.id.webView);
        mProgressbar = (ProgressBar) view.findViewById(R.id.progressbar);

        imageButton1 = imageButton1.findViewById(R.id.image1);
        imageButton2 = imageButton2.findViewById(R.id.image2);
        imageButton3 = imageButton3.findViewById(R.id.image3);
        imageButton4 = imageButton4.findViewById(R.id.image4);
        imageButton5 = imageButton5.findViewById(R.id.image5);

        imageButton1.setOnClickListener(this);
        imageButton2.setOnClickListener(this);
        imageButton3.setOnClickListener(this);
        imageButton4.setOnClickListener(this);
        imageButton5.setOnClickListener(this);

        WebSettings settings = mWebView.getSettings();

        settings.setJavaScriptEnabled(true);

        settings.setPluginState(PluginState.ON_DEMAND);

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {

                mProgressbar.setVisibility(View.VISIBLE);

                ActionBar actionBar = getActivity().getActionBar();
                if (actionBar != null) {
                    actionBar.setSubtitle(url);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {

                mProgressbar.setVisibility(View.GONE);
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {

                mProgressbar.setProgress(newProgress);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {

                ActionBar actionBar = getActivity().getActionBar();
                if (actionBar != null) {
                    actionBar.setTitle(title);
                }
            }
        });

        if (savedInstanceState == null) {
            mWebView.loadUrl("https://www.google.com/");
        } else {

            mWebView.restoreState(savedInstanceState);
        }

        return view;
    }

    @Override
    public void onClick(View v) {
         if(v.getId()==R.id.image1) {
             Intent intent = new Intent(getApplicationContext(), FreeImagesActivity.class);
             startActivity(intent);
         }
         else if (v.getId()==R.id.image2) {
                  Intent intent = new Intent(getApplicationContext(), PexelsActivity.class);
                  startActivity(intent);
         }
         else if (v.getId()==R.id.image3) {
                  Intent intent = new Intent(getApplicationContext(), UnsplashActivity.class);
                  startActivity(intent);
         }
         else if (v.getId()==R.id.image4) {
                  Intent intent = new Intent(getApplicationContext(), StockSnapActivity.class);
                  startActivity(intent);
         }
         else (v.getId()==R.id.image5) {
                  Intent intent = new Intent(getApplicationContext(), PixabayActivity.class);
                  startActivity(intent);
         }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        mWebView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    public WebView getWebView() {
        return mWebView;
    }

    @Override
    public void onPause() {
        super.onPause();

        mWebView.onPause();
    }

    @Override
    public void onResume() {
        mWebView.onResume();
        super.onResume();
    }

    @Override
    public void onDestroy() {

        if (mWebView != null) {
            mWebView.stopLoading();
            mWebView.setWebChromeClient(null);
            mWebView.setWebViewClient(null);
            mWebView.destroy();
            mWebView = null;
        }
        super.onDestroy();
    }
}
